// tvm target: c -keys=partial_conv,arm_cpu,cpu -mcpu=cortex-m4+nodsp -model=nrf52840
#define TVM_EXPORTS
#include "tvm/runtime/c_runtime_api.h"
#include "tvm/runtime/c_backend_api.h"
#include <math.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(float* p0, float* p1, float* p2, float* p3, float* p4, int32_t* p5, float* p6, int32_t* p7, float* p8, int32_t* p9, float* fusion_iter_worker, uint8_t* global_workspace_7_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros(float* T_full, uint8_t* global_workspace_1_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_1(int32_t* T_full, uint8_t* global_workspace_2_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_2(float* T_full, uint8_t* global_workspace_3_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_3(int32_t* T_full, uint8_t* global_workspace_4_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_4(float* T_full, uint8_t* global_workspace_5_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_5(int32_t* T_full, uint8_t* global_workspace_6_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee(int32_t* iterator, float* data, float* weight1, float* weight2, float* weight3, float* cache_buffer_var, int32_t* cache_cur_idx, float* cache_buffer_var_1, int32_t* cache_cur_idx_1, float* cache_buffer_var_2, int32_t* cache_cur_idx_2, float* conv2d_nchw, uint8_t* global_workspace_8_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* data_buffer_var, float* weight1_buffer_var, float* weight2_buffer_var, float* weight3_buffer_var, float* output_buffer_var, uint8_t* global_workspace_0_var);
#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_fusion_iter_worker(float* p0, float* p1, float* p2, float* p3, float* p4, int32_t* p5, float* p6, int32_t* p7, float* p8, int32_t* p9, float* fusion_iter_worker, uint8_t* global_workspace_7_var) {
  void* iterator_let = (&(global_workspace_7_var[11264]));
  void* bg_ind_let = (&(global_workspace_7_var[11280]));
  void* iteratee_output_let = (&(global_workspace_7_var[0]));
  ((int32_t*)iterator_let)[0] = 0;
  ((int32_t*)iterator_let)[1] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  ((int32_t*)iterator_let)[3] = 0;
  ((int32_t*)bg_ind_let)[0] = 0;
  ((int32_t*)bg_ind_let)[1] = 0;
  ((int32_t*)bg_ind_let)[2] = 0;
  ((int32_t*)bg_ind_let)[3] = 0;
  ((int32_t*)iterator_let)[2] = 0;
  while (1) {
    if (!((((int32_t*)bg_ind_let)[2] < 213))) { break; }
    ((int32_t*)iterator_let)[3] = 0;
    ((int32_t*)bg_ind_let)[3] = 0;
    p5[0] = 0;
    p5[1] = 0;
    p5[2] = 0;
    p5[3] = 0;
    p7[0] = 0;
    p7[1] = 0;
    p7[2] = 0;
    p7[3] = 0;
    p9[0] = 0;
    p9[1] = 0;
    p9[2] = 0;
    p9[3] = 0;
    while (1) {
      if (!((((int32_t*)bg_ind_let)[3] < 213))) { break; }
      if (tvmgen_default_iteratee(iterator_let, p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, iteratee_output_let, global_workspace_7_var) == 0) {
        for (int32_t n = 0; n < 1; ++n) {
          for (int32_t i = 0; i < 64; ++i) {
            for (int32_t j = 0; j < 1; ++j) {
              for (int32_t k = 0; k < 1; ++k) {
                fusion_iter_worker[(((((((int32_t*)bg_ind_let)[0] * 2930944) + (i * 45796)) + (((int32_t*)bg_ind_let)[1] * 45796)) + (((int32_t*)bg_ind_let)[2] * 214)) + ((int32_t*)bg_ind_let)[3])] = ((float*)iteratee_output_let)[(((((((int32_t*)bg_ind_let)[0] * 64) + i) + ((int32_t*)bg_ind_let)[1]) + ((int32_t*)bg_ind_let)[2]) + ((int32_t*)bg_ind_let)[3])];
              }
            }
          }
        }
        ((int32_t*)bg_ind_let)[3] = (((int32_t*)bg_ind_let)[3] + 1);
        if (((int32_t*)bg_ind_let)[3] == 213) {
          ((int32_t*)bg_ind_let)[2] = (((int32_t*)bg_ind_let)[2] + 1);
        }
      }
      ((int32_t*)iterator_let)[3] = (((int32_t*)iterator_let)[3] + 1);
    }
    ((int32_t*)iterator_let)[2] = (((int32_t*)iterator_let)[2] + 1);
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros(float* T_full, uint8_t* global_workspace_1_var) {
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 11; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3_outer = 0; ax3_outer < 2; ++ax3_outer) {
      for (int32_t ax3_inner = 0; ax3_inner < 4; ++ax3_inner) {
        if (((ax3_outer * 4) + ax3_inner) < 7) {
          T_full[(((ax0_ax1_fused_ax2_fused * 7) + (ax3_outer * 4)) + ax3_inner)] = 0.000000e+00f;
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_1(int32_t* T_full, uint8_t* global_workspace_2_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 4; ++ax0_inner) {
    T_full[ax0_inner] = 0;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_2(float* T_full, uint8_t* global_workspace_3_var) {
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 320; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3_inner = 0; ax3_inner < 3; ++ax3_inner) {
      T_full[((ax0_ax1_fused_ax2_fused * 3) + ax3_inner)] = 0.000000e+00f;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_3(int32_t* T_full, uint8_t* global_workspace_4_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 4; ++ax0_inner) {
    T_full[ax0_inner] = 0;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_4(float* T_full, uint8_t* global_workspace_5_var) {
  for (int32_t ax0_ax1_fused_ax2_fused = 0; ax0_ax1_fused_ax2_fused < 192; ++ax0_ax1_fused_ax2_fused) {
    for (int32_t ax3_inner = 0; ax3_inner < 3; ++ax3_inner) {
      T_full[((ax0_ax1_fused_ax2_fused * 3) + ax3_inner)] = 0.000000e+00f;
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_fused_zeros_5(int32_t* T_full, uint8_t* global_workspace_6_var) {
  for (int32_t ax0_inner = 0; ax0_inner < 4; ++ax0_inner) {
    T_full[ax0_inner] = 0;
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default_iteratee(int32_t* iterator, float* data, float* weight1, float* weight2, float* weight3, float* cache_buffer_var, int32_t* cache_cur_idx, float* cache_buffer_var_1, int32_t* cache_cur_idx_1, float* cache_buffer_var_2, int32_t* cache_cur_idx_2, float* conv2d_nchw, uint8_t* global_workspace_8_var) {
  void* dyn_slice_fixed_size_let = (&(global_workspace_8_var[3840]));
  void* cache_conv_input_compute_generic_let = (&(global_workspace_8_var[3840]));
  void* conv2d_nchw_let = (&(global_workspace_8_var[9984]));
  for (int32_t i2 = 0; i2 < 11; ++i2) {
    ((float*)dyn_slice_fixed_size_let)[i2] = data[(((((iterator[0] * 50176) + (iterator[1] * 50176)) + (i2 * 224)) + (iterator[2] * 224)) + iterator[3])];
  }
  for (int32_t n = 0; n < 1; ++n) {
    for (int32_t i = 0; i < 1; ++i) {
      for (int32_t j = 0; j < 11; ++j) {
        for (int32_t k = 0; k < 6; ++k) {
          int32_t cse_var_1 = ((j * 7) + k);
          cache_buffer_var[cse_var_1] = cache_buffer_var[(cse_var_1 + 1)];
        }
      }
    }
  }
  for (int32_t n_1 = 0; n_1 < 1; ++n_1) {
    for (int32_t j_1 = 0; j_1 < 1; ++j_1) {
      for (int32_t j_2 = 0; j_2 < 11; ++j_2) {
        for (int32_t k_1 = 0; k_1 < 1; ++k_1) {
          cache_buffer_var[((j_2 * 7) + 6)] = ((float*)dyn_slice_fixed_size_let)[j_2];
        }
      }
    }
  }
  cache_cur_idx[3] = (cache_cur_idx[3] + 1);
  if (6 <= cache_cur_idx[3]) {
    for (int32_t n_2 = 0; n_2 < 1; ++n_2) {
      for (int32_t k_2 = 0; k_2 < 1; ++k_2) {
        for (int32_t j_3 = 0; j_3 < 11; ++j_3) {
          for (int32_t k_3 = 0; k_3 < 7; ++k_3) {
            int32_t cse_var_2 = ((j_3 * 7) + k_3);
            ((float*)cache_conv_input_compute_generic_let)[cse_var_2] = cache_buffer_var[cse_var_2];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t ff = 0; ff < 64; ++ff) {
    for (int32_t yy = 0; yy < 5; ++yy) {
      ((float*)conv2d_nchw_let)[((ff * 5) + yy)] = 0.000000e+00f;
      for (int32_t ry = 0; ry < 7; ++ry) {
        for (int32_t rx = 0; rx < 7; ++rx) {
          int32_t cse_var_4 = (ry * 7);
          int32_t cse_var_3 = ((ff * 5) + yy);
          ((float*)conv2d_nchw_let)[cse_var_3] = (((float*)conv2d_nchw_let)[cse_var_3] + (((float*)cache_conv_input_compute_generic_let)[(((yy * 7) + cse_var_4) + rx)] * weight1[(((ff * 49) + cse_var_4) + rx)]));
        }
      }
    }
  }
  for (int32_t n_3 = 0; n_3 < 1; ++n_3) {
    for (int32_t i_1 = 0; i_1 < 64; ++i_1) {
      for (int32_t j_4 = 0; j_4 < 5; ++j_4) {
        for (int32_t k_4 = 0; k_4 < 2; ++k_4) {
          int32_t cse_var_5 = (((i_1 * 15) + (j_4 * 3)) + k_4);
          cache_buffer_var_1[cse_var_5] = cache_buffer_var_1[(cse_var_5 + 1)];
        }
      }
    }
  }
  for (int32_t n_4 = 0; n_4 < 1; ++n_4) {
    for (int32_t j_5 = 0; j_5 < 64; ++j_5) {
      for (int32_t j_6 = 0; j_6 < 5; ++j_6) {
        for (int32_t k_5 = 0; k_5 < 1; ++k_5) {
          cache_buffer_var_1[(((j_5 * 15) + (j_6 * 3)) + 2)] = ((float*)conv2d_nchw_let)[((j_5 * 5) + j_6)];
        }
      }
    }
  }
  cache_cur_idx_1[3] = (cache_cur_idx_1[3] + 1);
  if (2 <= cache_cur_idx_1[3]) {
    for (int32_t n_5 = 0; n_5 < 1; ++n_5) {
      for (int32_t k_6 = 0; k_6 < 64; ++k_6) {
        for (int32_t j_7 = 0; j_7 < 5; ++j_7) {
          for (int32_t k_7 = 0; k_7 < 3; ++k_7) {
            int32_t cse_var_6 = (((k_6 * 15) + (j_7 * 3)) + k_7);
            ((float*)cache_conv_input_compute_generic_let)[cse_var_6] = cache_buffer_var_1[cse_var_6];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t ff_1 = 0; ff_1 < 64; ++ff_1) {
    for (int32_t yy_1 = 0; yy_1 < 3; ++yy_1) {
      ((float*)conv2d_nchw_let)[((ff_1 * 3) + yy_1)] = 0.000000e+00f;
      for (int32_t rc = 0; rc < 64; ++rc) {
        for (int32_t ry_1 = 0; ry_1 < 3; ++ry_1) {
          for (int32_t rx_1 = 0; rx_1 < 3; ++rx_1) {
            int32_t cse_var_8 = (ry_1 * 3);
            int32_t cse_var_7 = ((ff_1 * 3) + yy_1);
            ((float*)conv2d_nchw_let)[cse_var_7] = (((float*)conv2d_nchw_let)[cse_var_7] + (((float*)cache_conv_input_compute_generic_let)[((((rc * 15) + (yy_1 * 3)) + cse_var_8) + rx_1)] * weight2[((((ff_1 * 576) + (rc * 9)) + cse_var_8) + rx_1)]));
          }
        }
      }
    }
  }
  for (int32_t n_6 = 0; n_6 < 1; ++n_6) {
    for (int32_t i_2 = 0; i_2 < 64; ++i_2) {
      for (int32_t j_8 = 0; j_8 < 3; ++j_8) {
        for (int32_t k_8 = 0; k_8 < 2; ++k_8) {
          int32_t cse_var_9 = (((i_2 * 9) + (j_8 * 3)) + k_8);
          cache_buffer_var_2[cse_var_9] = cache_buffer_var_2[(cse_var_9 + 1)];
        }
      }
    }
  }
  for (int32_t n_7 = 0; n_7 < 1; ++n_7) {
    for (int32_t j_9 = 0; j_9 < 64; ++j_9) {
      for (int32_t j_10 = 0; j_10 < 3; ++j_10) {
        for (int32_t k_9 = 0; k_9 < 1; ++k_9) {
          cache_buffer_var_2[(((j_9 * 9) + (j_10 * 3)) + 2)] = ((float*)conv2d_nchw_let)[((j_9 * 3) + j_10)];
        }
      }
    }
  }
  cache_cur_idx_2[3] = (cache_cur_idx_2[3] + 1);
  if (2 <= cache_cur_idx_2[3]) {
    for (int32_t n_8 = 0; n_8 < 1; ++n_8) {
      for (int32_t k_10 = 0; k_10 < 64; ++k_10) {
        for (int32_t j_11 = 0; j_11 < 3; ++j_11) {
          for (int32_t k_11 = 0; k_11 < 3; ++k_11) {
            int32_t cse_var_10 = (((k_10 * 9) + (j_11 * 3)) + k_11);
            ((float*)cache_conv_input_compute_generic_let)[cse_var_10] = cache_buffer_var_2[cse_var_10];
          }
        }
      }
    }
  } else {
    return -1;
  }
  for (int32_t ff_2 = 0; ff_2 < 64; ++ff_2) {
    conv2d_nchw[ff_2] = 0.000000e+00f;
    for (int32_t rc_1 = 0; rc_1 < 64; ++rc_1) {
      for (int32_t ry_2 = 0; ry_2 < 3; ++ry_2) {
        for (int32_t rx_2 = 0; rx_2 < 3; ++rx_2) {
          int32_t cse_var_12 = (rc_1 * 9);
          int32_t cse_var_11 = (ry_2 * 3);
          conv2d_nchw[ff_2] = (conv2d_nchw[ff_2] + (((float*)cache_conv_input_compute_generic_let)[((cse_var_12 + cse_var_11) + rx_2)] * weight3[((((ff_2 * 576) + cse_var_12) + cse_var_11) + rx_2)]));
        }
      }
    }
  }
  return 0;
}

#ifdef __cplusplus
extern "C"
#endif
TVM_DLL int32_t tvmgen_default___tvm_main__(float* data_buffer_var, float* weight1_buffer_var, float* weight2_buffer_var, float* weight3_buffer_var, float* output_buffer_var, uint8_t* global_workspace_0_var) {
  void* sid_5_let = (&(global_workspace_0_var[3884]));
  void* sid_7_let = (&(global_workspace_0_var[11312]));
  void* sid_6_let = (&(global_workspace_0_var[0]));
  void* sid_4_let = (&(global_workspace_0_var[9984]));
  void* sid_8_let = (&(global_workspace_0_var[7680]));
  void* sid_9_let = (&(global_workspace_0_var[11296]));
  if (tvmgen_default_fused_zeros(sid_4_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_zeros_1(sid_5_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_zeros_2(sid_6_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_zeros_3(sid_7_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_zeros_4(sid_8_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_zeros_5(sid_9_let, global_workspace_0_var) != 0 ) return -1;
  if (tvmgen_default_fused_fusion_iter_worker(data_buffer_var, weight1_buffer_var, weight2_buffer_var, weight3_buffer_var, sid_4_let, sid_5_let, sid_6_let, sid_7_let, sid_8_let, sid_9_let, output_buffer_var, global_workspace_0_var) != 0 ) return -1;
  return 0;
}

